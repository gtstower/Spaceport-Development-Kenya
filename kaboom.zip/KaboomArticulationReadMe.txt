Proper Kaboom Articulation Method:

The Kaboom model is designed such that three phases occur during the explosion.  The first phase is a quick flash at the initial ignition of the explosion.  This portion is denoted as "Boom" in the articulation file.  To get the full effect, "Boom" should be set to appear at 50% size at the first second of the explosion.  One second later it should be followed by a new "Boom" articulation that starts at size 0, explanding to 100% over a period of 10% of the explosion animation time.  Finally, during the last half of the total duration of the "Boom" articulation, the "fade" transformation should reduce to 0.

The second phase consists of the larger scale explosion articulation called "Explode".  This articulation should be set such that it begins at size 0 at the beginning of the explosion to size 100 at the end of the duration of the explosion.  At the halfway point of the explosion, the "fade" transformation should begin at maximum value and take the rest of the explosion time to fall to 0.

The last phase is denoted by the "Debris" articulation.  This should have about a 10% time delay before starting.  After the delay, the Debris should start at size value 0 and increase to the maximum value over the same amount of time as the rest of the explosion (meaning debris should exist 10% longer than the rest of the animation).  Again, during the last half of the explosion, the debris "fade" transformation should fall to 0.

Finally, after the articulation file is made, saved and loaded, the user must change one last 3D Graphics option on the model.  Under "Model Pointing" in the 3D Graphics object properties, change the Assigned Target Object of "AimExplodeBottom", "AimExplodeTop" and "Glow" to the Avialable Target of Viewer.

Example Articulation file:

VO_v80

#Boom Flash
NEW_ARTICULATION 
STARTTIME       1
DURATION        0
DEADBANDDURATION 0.000000
ACCELDURATION    0.000000
DECELDURATION    0.000000
DUTYCYCLEDELTA   0.000000
PERIOD           0.0
ARTICULATION     Boom
TRANSFORMATION   size
STARTVALUE       0
ENDVALUE         50

#Boom Expansion
NEW_ARTICULATION 
STARTTIME       2
DURATION        35
DEADBANDDURATION 0.000000
ACCELDURATION    0.000000
DECELDURATION    0.000000
DUTYCYCLEDELTA   0.000000
PERIOD           0.0
ARTICULATION     Boom
TRANSFORMATION   size
STARTVALUE       1
ENDVALUE         50

#Boom Fade Out
NEW_ARTICULATION 
STARTTIME       15
DURATION        15
DEADBANDDURATION 0.000000
ACCELDURATION    0.000000
DECELDURATION    0.000000
DUTYCYCLEDELTA   0.000000
PERIOD           0.0
ARTICULATION     Boom
TRANSFORMATION   fade
STARTVALUE       8
ENDVALUE         0

###################

#Explode Expansion
NEW_ARTICULATION 
STARTTIME       0
DURATION        400
DEADBANDDURATION 0.000000
ACCELDURATION    0.000000
DECELDURATION    0.000000
DUTYCYCLEDELTA   0.000000
PERIOD           0.0
ARTICULATION     Explode
TRANSFORMATION   size
STARTVALUE       0
ENDVALUE         100

#Explode Fade out
NEW_ARTICULATION 
STARTTIME       200
DURATION        200
DEADBANDDURATION 0.000000
ACCELDURATION    0.000000
DECELDURATION    0.000000
DUTYCYCLEDELTA   0.000000
PERIOD           0.0
ARTICULATION     Explode
TRANSFORMATION   fade
STARTVALUE       8
ENDVALUE         0

#################

#Debris Expansion
NEW_ARTICULATION 
STARTTIME       20
DURATION        600
DEADBANDDURATION 0.000000
ACCELDURATION    0.000000
DECELDURATION    0.000000
DUTYCYCLEDELTA   0.000000
PERIOD           0.0
ARTICULATION     Debris
TRANSFORMATION   size
STARTVALUE       0
ENDVALUE         150

#Debris Fade out
NEW_ARTICULATION 
STARTTIME       220
DURATION        200
DEADBANDDURATION 0.000000
ACCELDURATION    0.000000
DECELDURATION    0.000000
DUTYCYCLEDELTA   0.000000
PERIOD           0.0
ARTICULATION     Debris
TRANSFORMATION   fade
STARTVALUE       8
ENDVALUE         0
